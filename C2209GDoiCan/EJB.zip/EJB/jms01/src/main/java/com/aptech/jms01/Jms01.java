

package com.aptech.jms01;

public class Jms01 {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
